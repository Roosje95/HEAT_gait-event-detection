function v = btkGetVersion()
%V = BTKGETVERSION returns the release number of BTK.

%  Author: A. Barré
%   Copyright 2009-2013 Biomechanical ToolKit
v = '0.3.0';
